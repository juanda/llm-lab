# Plan de Estudios LLM Lab

## Módulos
0. Preparación del laboratorio
1. Anatomía de un LLM
2. Generación de texto
3. Contexto y memoria
4. Prompt Engineering
5. Razonamiento
6. Comparativa de modelos
7. Entrenamiento
8. Alineamiento
9. Alucinaciones
10. Embeddings
11. RAG
12. Tool Calling
13. Agentes
14. Interpretabilidad
15. Proyecto Final

Cada módulo debe contener:
- Conceptos
- Hipótesis
- Experimentos
- Observaciones
- Conclusiones
